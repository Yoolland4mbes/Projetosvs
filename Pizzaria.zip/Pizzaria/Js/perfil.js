//EXIBIR AS INFORMAÇÕES DO PERFIL
const nome = "Yollanda"

const telefone = "11986544677"

const email = "yollandamoraes07@gmail.com"

const endereco = "Rua hayako yamauchi 162"

console.log(`User: ${nome}, Telefone: ${telefone}, Email ${email}, Endereço:  ${endereco}`);