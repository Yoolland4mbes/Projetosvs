let senha1 = "Yollanda1@"
let senha2 = "Yollanda1@"

function testarSenha() {

        
    if (senha1 === senha2) {
        console.log ("senha correta")
        
    } else {
        console.log("Senha incorreta, tente novamente")
        
    }
    
}



//-------------------------------------------------------------------------------------//



let email1 = "yollandamoraes07@gmail.com"
let email2 = "yollanda1@gmail.com"

function testarEmail() {

        
    if (email1 === email2) {
        console.log ("Email correto")
        
    } else {
        console.log("E-mail incorreto, tente novamente")
        
    }
    
}




testarSenha ()
testarEmail()