let user = "Yollanda"
let senha1 = 'yollanda'
let senha2 = 'yollanda1@'
let cadastrotelefone = "11986544677"

const regex = /\W|_/;

// console.log(regex.test(senha1) +   " Senha fraca, insira caracteres especiais")
//Usei o stack overflow para descobrir como identificar algum caractere especial

console.log(regex.test(senha2) + " Senha forte.")

//---------------------------------------------------------------------------------------------------------------------


function ValidarSenha() {
    if (senha1.length < 7 ) {
        console.log('Senha muito curta');
    }

    else{
        console.log("Senha bem sucedida, vá para a confirmação de senha")
    }
}

//---------------------------------------------------------------------------------------------------------------------


function ConfirmarSenha() {
    if (senha1 != senha2 ) {
        console.log('Senhas não coincidem');
    }

    else{
        console.log("Senhas bem sucedidas!")
        
    }
}

//---------------------------------------------------------------------------------------------------------------------


function telefone() {
    if (cadastrotelefone >= 11) {
        console.log("Telefone registrado com sucesso!");
        
    } else {
        console.log("O registro falhou. Apenas 11 números são aceitos");
        
    }
    
}
//---------------------------------------------------------------------------------------------------------------------

function CriarUser(params) {
    if (user.length < 7 ) {
        console.log("Não foi possivel fazer o cadastro, Minimo de 7 letras");
        
    } else {
        console.log("Usuário Registrado com sucesso!");
    }
}



ValidarSenha()
ConfirmarSenha()
telefone()
CriarUser()


