    //pizzas


    //Usei como referencia: ajuda de amigos e o site "stackoverflow" e "acervo lima"
    const pizzas = [
        { nome: 'Brigadeiro', preco: 23 },

        { nome: 'Calabresa', preco: 20 },
            
        { nome: 'pepperoni', preco: 38},

        { nome: 'Doritos', preco: 45 },
        
        { nome: 'Portuguesa', preco: 32}
    ];

        function procuraapizza(nome) {
            const eumnumero = !isNaN(parseFloat(nome)) && isFinite(nome);
            
            // deixar o termo em letras minúsculas
            const termoLowerCase = nome.toLowerCase();
            
            const pizzasFiltradas = pizzas.filter(pizza => {
            if (eumnumero) {
                return pizza.preco == nome;
            } else {
                return pizza.nome.toLowerCase().includes(termoLowerCase);
            }
            });
            
            return pizzasFiltradas;
        }

        console.log(procuraapizza('calabresa'));  
        console.log(procuraapizza('35'));